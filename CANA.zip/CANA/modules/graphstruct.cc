#include "graphstruct.h"
#include <math.h>

//#define DEBUG_GRAPHNODES

namespace inet{

spacegraph::spacegraph(){
}
spacegraph::~spacegraph(){

}
void spacegraph::buildgraphnodes(std::map<std::string, Coord> nodes){
    std::cout <<"spacegraph.cc file! " <<std::endl;
    for (std::map <std::string, Coord>::iterator i = nodes.begin(); i != nodes.end(); i++ ){
        node tmpn;
        tmpn.curNodeID = i->first;
        tmpn.NodePos = i->second;
        for (std::map <std::string, Coord>::iterator ii = nodes.begin(); ii != nodes.end(); ii++){
            if (std::strcmp(i->first.c_str(), ii->first.c_str()) != 0){
                double dstnce =sqrt(pow((i->second.x - ii->second.x), 2) + pow((i->second.y - ii->second.y), 2) + pow((i->second.z - ii->second.z), 2));
                tmpn.neighNodes.insert(std::make_pair(ii->first, dstnce));
            }
        }
        graphnodes.push_back(tmpn);
    }

#ifdef DEBUG_GRAPHNODES
    for (auto i:graphnodes){
        std::cout <<i.curNodeID <<"; ("<< i.NodePos.x<<"; " <<i.NodePos.y << "; " <<i.NodePos.z <<"); Neighbors: " <<std::endl;
        for(auto ii:i.neighNodes){
            std::cout <<ii.first <<" = " <<ii.second<<"  :  ";
        }
        std::cout <<std::endl;
    }
#endif
}
void spacegraph::updateGraphNodes(std::vector<node> addupdate, std::vector<node> reductionupdate){
    for (auto i:reductionupdate){
        for (int j = 0; j < graphnodes.size(); j++){
            if (std::strcmp(graphnodes[j].curNodeID.c_str(), i.curNodeID.c_str()) == 0){
                for (auto k:i.flyingDrones){
                    std::map<std::string, double>::iterator it;
                    it = graphnodes[j].flyingDrones.find(k.first);
                    if (it != graphnodes[j].flyingDrones.end()){
                        graphnodes[j].flyingDrones.erase(k.first);
                    }
                }
                break;
            }
        }
    }
    for (auto i:addupdate){
        for (int j = 0; j < graphnodes.size(); j++){
            if (std::strcmp(graphnodes[j].curNodeID.c_str(), i.curNodeID.c_str()) == 0){
                for (auto k:i.flyingDrones){
                    graphnodes[j].flyingDrones.insert(std::make_pair(k.first,k.second));
                }
                break;
            }
        }
    }
}
}
