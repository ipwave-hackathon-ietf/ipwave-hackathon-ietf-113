	Context-Aware Navigation Algorithm (CANA) in Drone Network
	__________________________________________________________
	
	Versions:
	________
	
	OMNeT++ version 5.6.2
	INET    version Use the version provided with the CANA-Dyn source codes.
		
	Import inet and CANA-Dyn in your simulator!
	
	Configuration:
	______________	
	(1) Linking INET to CANA-Dyn
	Right Click CANA-Dyn >>> properties  >>> Project References >>>  tick inet >>>   Apply and close.
	
	(2)In CANASimulation/fanetsimulations/omnetpp.ini, Rchoose CANAight click it >>> Run as >>OMNeT++ Simulation, choose CANA as inifile configuration.




        Enjoy our Simulator!
